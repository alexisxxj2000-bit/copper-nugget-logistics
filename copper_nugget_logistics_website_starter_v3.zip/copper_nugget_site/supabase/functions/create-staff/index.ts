import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
  try {
    const authHeader = req.headers.get('Authorization'); if (!authHeader) return new Response(JSON.stringify({ error: 'Sign-in required' }), { status: 401, headers: cors });
    const url = Deno.env.get('SUPABASE_URL')!; const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin = createClient(url, serviceKey); const caller = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: authError } = await caller.auth.getUser(); if (authError || !user) return new Response(JSON.stringify({ error: 'Invalid session' }), { status: 401, headers: cors });
    const { data: role, error: roleError } = await admin.from('user_roles').select('role').eq('user_id', user.id).maybeSingle();
    if (roleError || role?.role !== 'admin') return new Response(JSON.stringify({ error: 'Admin access required' }), { status: 403, headers: cors });
    const body = await req.json(); const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : ''; const password = typeof body?.password === 'string' ? body.password : '';
    if (!email || !email.includes('@') || password.length < 12) return new Response(JSON.stringify({ error: 'Provide a valid email and a temporary password of at least 12 characters.' }), { status: 400, headers: cors });
    const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: false });
    if (createError || !created.user) throw createError || new Error('Account creation failed');
    const { error: insertError } = await admin.from('user_roles').insert({ user_id: created.user.id, role: 'staff' });
    if (insertError) { await admin.auth.admin.deleteUser(created.user.id); throw insertError; }
    return new Response(JSON.stringify({ success: true, message: 'Staff account created. Ask the staff member to complete email confirmation and sign in.' }), { headers: cors });
  } catch (e) { console.error(e); return new Response(JSON.stringify({ error: 'Could not create staff account. Check function logs.' }), { status: 500, headers: cors }); }
});
